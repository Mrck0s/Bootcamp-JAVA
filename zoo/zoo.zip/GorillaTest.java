package zoo;

public class GorillaTest {
  public static void main(String[] args) {
    Gorilla george = new Gorilla();
    george.throwSomething();
    george.throwSomething();
    george.throwSomething();
    george.eatBananas();
    george.eatBananas();
    
  }

}
