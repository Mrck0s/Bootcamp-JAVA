

public class BatTest {
  public static void main(String[] args) {
    Bat drac = new Bat();
    drac.attackTown();
    drac.attackTown();
    drac.attackTown();
    drac.eatHumans();
    drac.eatHumans();
    drac.fly();
    drac.fly();
    drac.displayEnergy();
  }
}