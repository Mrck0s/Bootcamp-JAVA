public class MiPrimerProgramaJava{
  public static void main (String[] args){
    System.out.println("Mi nombre es Coding Dojo");
    System.out.println("Tengo 100 años de edad.");
    System.out.println("Mi ciudad es Burbank, CA");
  }
}