public class ProjectTest {
  public static void main(String[] args) {
    Project np = new Project();
    System.out.println(np.elevatorPitch());
    System.out.println(np.elevatorPitch("Detergente", 230.5));
    System.out.println(np.elevatorPitch("Detergente", 230.5, "Vegano"));


  }
}
